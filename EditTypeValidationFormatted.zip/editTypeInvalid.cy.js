const { Given, Then } = require('@badeball/cypress-cucumber-preprocessor');
const ticketsPage = require('../../../pages/TicketsPage');
const filename = Cypress.env('intentValidationFilename4');
let value = "Allowed values are : '[STANDARD, LIVE]'";
let expectedErrorValue = "edit type";

Given("I enter invalid Edit Type 'ABCDEFGH'", () => {
  ticketsPage.visit();
});

Then("I should see an error message for edit type \"Allowed values are : '[STANDARD, LIVE]'\"", () => {
  return ticketsPage.intentValidation(filename, value, expectedErrorValue);
});
