const { Given, Then } = require('@badeball/cypress-cucumber-preprocessor');
const ticketsPage = require('../../../pages/TicketsPage');
const filename = Cypress.env('intentValidationFilename4');
let value = "Length cannot exceed 8";
let expectedErrorValue = "edit type";

Given("I exceed max length in the Edit Type field", () => {
  ticketsPage.visit();
});

Then("I should see an error message for edit type \"Length cannot exceed 8\"", () => {
  return ticketsPage.intentValidation(filename, value, expectedErrorValue);
});
