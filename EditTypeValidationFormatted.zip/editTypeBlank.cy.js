const { Given, Then } = require('@badeball/cypress-cucumber-preprocessor');
const ticketsPage = require('../../../pages/TicketsPage');
const filename = Cypress.env('intentValidationFilename4');
let value = "Field is Required.";
let expectedErrorValue = "edit type";

Given("I leave the Edit Type field blank", () => {
  ticketsPage.visit();
});

Then("I should see an error message for edit type \"Field is Required.\"", () => {
  return ticketsPage.intentValidation(filename, value, expectedErrorValue);
});
