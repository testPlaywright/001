import { Given, When, Then } from "cypress-cucumber-preprocessor/steps";
import ticketsPage from "../../../pom/pages/TicketsPage"

When("I click create ticket and fill the detail and upload {string}", (filename) => {
  ticketsPage.openUploadDialog();
  ticketsPage.uploadFile(filename);
  ticketsPage.fillTicketForm();
});

Then("I should be able to create a ticket successfully", () => {
  ticketsPage.getTicketID();
  ticketsPage.verifyAlertMessage("Ticket Created Successfully");
});
