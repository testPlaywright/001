
import { Given, When, Then } from "cypress-cucumber-preprocessor/steps";
import ticketsPage from "../../../pom/pages/TicketsPage"

When("I enter the ticket ID and click on Search button", () => {
  ticketsPage.updateTicketFlow().then(() => {
    ticketsPage.searchTicketID();
  });
});

Then("I should be able to view the searched ticket successfully", () => {
  ticketsPage.clickSearchedTicket();
  ticketsPage.getTicketStatusElement().should('be.visible');
});
