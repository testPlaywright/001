
import ticketsPage from "../../../pom/pages/TicketsPage"

When("I enter the ticket status and click on Search button", () => {
  ticketsPage.searchTicketStatus();
  ticketsPage.clickSearchedTicket();
});

Then("I should be able to click on Close and ticket should be closed successfully", () => {
  ticketsPage.clickCloseButton();
  ticketsPage.getAlertMessageElement()
    .should('be.visible')
    .invoke('text')
    .should('contain', 'Ticket Closed Successfully');
});
