import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
Given('I leave the "Product ID" field blank', () => {
  cy.get('[data-testid="Product ID"]').clear();
});
When('I submit the form', () => {
  cy.get('[data-testid="submit-button"]').click();
});
Then('I should see an error message "Product ID is mandatory"', () => {
  cy.contains("Product ID is mandatory").should('be.visible');
});
