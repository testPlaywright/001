import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
Given('I enter "ABCDEFGHIJKLMN" in the "Product ID" field', () => {
  cy.get('[data-testid="Product ID"]').clear().type("ABCDEFGHIJKLMN");
});
When('I submit the form', () => {
  cy.get('[data-testid="submit-button"]').click();
});
Then('I should see an error message "Product ID must not exceed 14 characters"', () => {
  cy.contains("Product ID must not exceed 14 characters").should('be.visible');
});
