import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
Given('I enter "12345678901" in the "Product ID" field', () => {
  cy.get('[data-testid="Product ID"]').clear().type("12345678901");
});
When('I submit the form', () => {
  cy.get('[data-testid="submit-button"]').click();
});
Then('I should see an error message "Product ID cannot be numeric only"', () => {
  cy.contains("Product ID cannot be numeric only").should('be.visible');
});
