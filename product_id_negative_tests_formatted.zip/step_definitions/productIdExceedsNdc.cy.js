import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
Given('I enter "ABCDEFGHIJKL" in the "Product ID" field', () => {
  cy.get('[data-testid="Product ID"]').clear().type("ABCDEFGHIJKL");
});
When('I submit the form', () => {
  cy.get('[data-testid="submit-button"]').click();
});
Then('I should see an error message "Product ID must not exceed 11 characters"', () => {
  cy.contains("Product ID must not exceed 11 characters").should('be.visible');
});
