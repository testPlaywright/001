import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
Given('I enter "ABC 123" in the "Product ID" field', () => {
  cy.get('[data-testid="Product ID"]').clear().type("ABC 123");
});
When('I submit the form', () => {
  cy.get('[data-testid="submit-button"]').click();
});
Then('I should see an error message "Product ID must not contain spaces"', () => {
  cy.contains("Product ID must not contain spaces").should('be.visible');
});
